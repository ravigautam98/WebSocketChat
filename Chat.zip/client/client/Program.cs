﻿namespace client
{
    using System;
    using System.Net.WebSockets;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    internal class Program
    {
        static async Task Main(string[] args)
        {
            using (ClientWebSocket client = new ClientWebSocket())
            {
                await client.ConnectAsync(new Uri("ws://localhost:8080/"), CancellationToken.None);
                Console.WriteLine("Connected to WebSocket server");

                Task sendTask = SendMessages(client);
                Task receiveTask = ReceiveMessages(client);

                await Task.WhenAll(sendTask, receiveTask);
            }
        }

        static async Task SendMessages(ClientWebSocket client)
        {
            while (client.State == WebSocketState.Open)
            {
                string message = Console.ReadLine();
                byte[] buffer = Encoding.UTF8.GetBytes(message);
                await client.SendAsync(new ArraySegment<byte>(buffer), WebSocketMessageType.Text, true, CancellationToken.None);
            }
        }

        static async Task ReceiveMessages(ClientWebSocket client)
        {
            byte[] buffer = new byte[1024 * 4];
            while (client.State == WebSocketState.Open)
            {
                WebSocketReceiveResult result = await client.ReceiveAsync(new ArraySegment<byte>(buffer), CancellationToken.None);
                string message = Encoding.UTF8.GetString(buffer, 0, result.Count);
                Console.WriteLine("Received from server: " + message);
            }
        }
    }
}
